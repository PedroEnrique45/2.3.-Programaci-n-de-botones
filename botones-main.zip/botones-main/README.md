# botones
2.3. Programación de botones
